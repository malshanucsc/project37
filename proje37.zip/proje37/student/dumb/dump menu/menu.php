<link rel="stylesheet" type="text/css" href="css/menu.css">


  <a style="height:5%;" href="javascript:void(0)" class="closebtn" onclick="closeNav('sp1')"> <img src="../image/menuback.png" alt="hide image"></a>
  
  <h1 id=menuid style="color:white; "> &nbsp&nbsp Menu </h1>


  <a style="height:2%;" href="course.php?courseIDpass=<?php echo $courseID; ?>&batch_No=<?php echo $batch_No ?> "  >Current Course</a>
<br><br>
  <a style="height:2%;" href="modules.php">Lessons</a>
  <br><br>
  <a style="height:2%;" href="quiz.php" target="_parent" >Quizzes</a>
  <br><br>
  <a style="height:2%;" href="assignment.php" target="_parent" >Assignments</a>
  <br><br>
  <a style="height:2%;" href="performance.php" >Performance</a>

<br><br>

<!--
  <a style="height:1%;" href="" ><?php include("calender/examples/calenderview.html") ?> </a>
-->
 <!--  <iframe id ="ivf2" class="overlay" width="100%" scrolling="no" frameborder="0" height="100%" src="calender/examples/calenderview.html" onload="this.style.height=this.contentDocument.body.scrollHeight +'px';" name="iframe_calender"   style="margin-bottom:0px ; overflow-y: auto;"></iframe>
*/
-->
