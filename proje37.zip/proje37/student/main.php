<!--<div id="main"  scrolling="no" style=" width:66%;float:left; margin-top:0%; border: none!important;" href="#mySidenav">
-->
<div>
<?php
$courseIDfordefalut=$_SESSION['Course_ID'];
    include("defaultcoursepage.php");
?>

</div>




