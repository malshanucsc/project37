<!DOCTYPE html>
<html>
<head>

<style>

/*
a:link    { color: #c00 }  
a:visited { color: #0c0 }  
a:hover   { color: #00c }  
a:active  { color: #ccc } 

*/
</style>
    
<link rel="stylesheet" type="text/css" href="../public/css/component.css">
<link rel="stylesheet" type="text/css" href="../public/css/normalize.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js">




</script>



</head>	
<body>
    
    
    
    
 <div style="text-align:center;">
     <lable style="font-size:200%;">Menu</lable>
    
        
    <section class="color-10">
				<nav class="cl-effect-10">
					<a href="course.php?courseIDpass=<?php echo $courseID; ?>&batch_No=<?php echo $batch_No ?>" data-hover="Current course"><span>Current Course</span></a>
					<a href="modules.php" data-hover="Lessons"><span>Lessons</span></a>
					<a href="#" data-hover="Quizzes"><span>Quizzes</span></a>
					<a href="assignment.php" data-hover="Assignments"><span>Assignments</span></a>
					<a href="performance.php" data-hover="Performance"><span>Performance</span></a>
				</nav>
			</section>
    
    
    
    
    
    
    

    <!--
    <div id=menu>
<lable style="font-size:200%;">Menu</lable>
<hr>
<ul>



 <li> <a href="course.php?courseIDpass=<?php echo $courseID; ?>&batch_No=<?php echo $batch_No ?> ">Current Course</a></li>
<br>
<li>  <a  href="modules.php" onclick="changeColor(this);">Lessons</a></li>
  <br>
  <li><a  href="#" target="_parent" >Quizzes</a></li>
  <br>
 <li> <a  href="assignment.php" target="_parent" >Assignments</a></li>
  <br>
<li>  <a  href="performance.php" >Performance</a></li>

<br>



</ul>
-->
</div>

</body>
</html>
