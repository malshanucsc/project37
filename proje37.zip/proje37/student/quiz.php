 <?php
    session_start();

    
    
        $now = time(); // Checking the time now when home page starts.

        if (time() - $_SESSION['start'] > 10000) {
            session_destroy();
            echo "Your session has expired! <a href='../login.php'>Login here</a>";
        }
        else{
            $_SESSION['start']=time();
          ?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equi="Content-Type" content="text/html; charset=utf-8"/>
<title>R I T T I</title>
<link rel="stylesheet" type="text/css" href="menustyles.css">
<style type="text/css">
body {
    font-family: "calibri", sans-serif;
}
.iframe{display:none;}
a:link, a:visited {
    background-color: #333;
    color: white;
  
        padding-bottom: 15px;
        padding-top: 10px;
        padding-left: 10px;
        padding-right: 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    height:10px
}
a:focus  {
  background: black;
  outline: 0;
}
a:hover, a:active {
    background-color: black;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
     float: left;

      
}



ul li {

    float: none;
    
    background: #333;
    height:10px
    color: white;
    text-align: center;
    padding: 0px 0px;
    text-decoration: none;
    
}

ul li:hover {
    background-color: #111;
}




.sidenav {
    height: 40%;
    width: 100%;
   position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.2s;
    padding-top: 40px;
     padding-bottom: 10px;
    display:block;
     border-style: double;
      border-radius: 10px;
     border: 2px double #5B9AB0; 
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 15px;
    color: #818181;
    display: block;
    transition: 0.3s;
    
  width:100%;
}

.sidenav a:hover, .offcanvas a:focus{
    color: #f1f1f1;

}

.closebtn {
    position: absolute;
    margin-top:-25%;
    font-size: 36px !important;
    
      text-align: right;
}

#main {
    transition: margin-left 0.3s;
    padding: 16px;

    margin-left:250px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.overlay{
  display:block;
  float:left;
}

#mySidenav{width:15%;}






</style>




<script>
function ifr(id1,id2){
var e2 = document.getElementById(id2);
var e = document.getElementById(id1);

e2.innerHTML = 'Assignments';
 e.style.display = 'block';


}




function openNav(sp1) {
    var e = document.getElementById(sp1);
    e.style.display='none'
    document.getElementById("mySidenav").style.width = "15%";
    document.getElementById("main").style.marginLeft = "250px";
     document.getElementById("main").style.width= "66%";
}

function closeNav(sp1) {
    var e = document.getElementById(sp1);
    e.style.display='block';
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "30px";
    document.getElementById("main").style.width= "80%";
}
</script>
<link rel="icon" href="../image/rittilogo.png" type="image/gif" sizes="16x16">



</head>
<body style="background-color:#8DA7B0; ">


<iframe id="ifass" width="100%" height="250px" frameborder="0" src="user_home.php" ></iframe>

 
<?php
$courseID=$_SESSION['Course_ID'];

  include("menu.php");
?>


<div id="main"  scrolling="no" style=" width:66%;float:left; margin-top:-3.5%;border: none !important;" href="#mySidenav">
 
  <span id ="sp1" style="display:none; width:100px;font-size:20px;cursor:pointer;"  onclick="openNav('sp1')">Menu >></span>

<hr>
<br>


<?php


include '../db.php';

$courseforQuiz=$_SESSION['Course_ID'];


$UserIDfordefault=$_SESSION['username'];
$sql = "SELECT quiz_Id FROM do_quiz WHERE course_Id='$courseforQuiz;' AND user_Id='$UserIDfordefault' ";
//$sql2 = "SELECT link FROM assignment ";
$result = $conn->query($sql);

//$row = $result->fetch_assoc();



if ($result->num_rows > 0) {
    // output data of each row
    //target="iframe_a"?>
        
    <?php
    while($row= $result->fetch_assoc() ) {
    //echo $row['link'];
    //$lin=$row['link'];
    /*<?php$row['link']?>*/
    $passQuizID=$row['quiz_Id'];

    $sql2 = "SELECT * FROM quiz WHERE quiz_Id ='$passQuizID' ";
    $result2 = $conn->query($sql2);

    if ($result2->num_rows > 0) {
    // output data of each row
    //target="iframe_a"?>
        <ul>
    <?php
    while($row2= $result2->fetch_assoc() ) {


    ?>

     <li ><a href="doquiz.php?quizIDpass=<?php echo $passQuizID ?>" ><?php echo $row2['module'] ?></a></li>

    <?php
      
    }
    ?>  </ul>
    <?php
}
}
}
?>
<!--
<div ><iframe id ="ivf1" class="overlay" width="100%" scrolling="no" frameborder="0" height="900px" src="" onload="this.style.height=this.contentDocument.body.scrollHeight +'px';" name="iframe_c"></iframe>
</div>-->
</div>

<div id="msg">

<?php
    include("msgnotification.php");
?>
</div>



</body>
</html>
<?php
}
?>