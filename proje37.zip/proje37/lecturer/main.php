

<div id="main"  scrolling="no" style=" width:66%;float:left; margin-top:-4%; border: none !important;" href="#mySidenav">
 
<span id ="sp1" style="display:none; width:100px;font-size:20px;cursor:pointer;"  onclick="openNav('sp1')">Menu >></span>
<hr>
<br>

<?php

    include("defaultcoursepage.php");
?>
</div>




